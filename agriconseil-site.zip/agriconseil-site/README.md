# AgriConseil — Guide de mise en ligne

Ce dossier contient tout le site : le front (`index.html`) et les fonctions serveur
qui gardent tes clés secrètes (`netlify/functions/`).

## Ce qu'il te faut avant de commencer

1. Un compte **Netlify** (gratuit) : https://app.netlify.com/signup
2. Un compte **GitHub** (gratuit) : https://github.com/signup — Netlify déploie depuis un dépôt Git
3. Une **clé API Anthropic** : https://console.anthropic.com → Settings → API Keys
4. Un compte **NotchPay** (gratuit) : https://business.notchpay.co/signup
   - Une fois inscrit, va dans *Developer → API Keys* pour récupérer ta clé publique et ta clé privée
   - Relie ton compte MTN MoMo ou Orange Money dans les paramètres pour recevoir les paiements

## Étape 1 — Mettre le code sur GitHub

1. Crée un nouveau dépôt sur GitHub (ex: `agriconseil`)
2. Mets tous les fichiers de ce dossier dedans (via l'interface web GitHub : "Upload files", ou via Git si tu es à l'aise)

## Étape 2 — Déployer sur Netlify

1. Sur Netlify, clique "Add new site" → "Import an existing project"
2. Choisis GitHub, autorise l'accès, sélectionne ton dépôt `agriconseil`
3. Laisse les réglages par défaut (le fichier `netlify.toml` s'occupe de tout) et clique "Deploy"
4. Ton site est en ligne à une adresse du type `https://ton-site-123.netlify.app`

## Étape 3 — Ajouter tes clés secrètes (variables d'environnement)

Sur Netlify : **Site settings → Environment variables → Add a variable**, ajoute :

| Nom | Valeur | Exemple |
|---|---|---|
| `ANTHROPIC_API_KEY` | ta clé API Anthropic | `sk-ant-...` |
| `NOTCHPAY_PUBLIC_KEY` | clé publique NotchPay | `pk_...` |
| `NOTCHPAY_PRIVATE_KEY` | clé privée NotchPay | `sk_...` |
| `APP_SECRET` | une phrase secrète inventée par toi, longue et unique | `mon-secret-super-long-a-ne-jamais-partager` |
| `PRICE_XAF` | le prix de l'accès illimité en FCFA | `500` |
| `SITE_URL` | l'adresse de ton site une fois déployé | `https://ton-site-123.netlify.app` |

Après avoir ajouté les variables, va dans **Deploys** et clique "Trigger deploy" pour que le site les prenne en compte.

## Étape 4 — Tester

1. Ouvre ton site, pose 3 questions gratuites → la 4e doit proposer le paiement
2. Clique "Débloquer l'accès illimité", entre un email et ton numéro Mobile Money
3. Effectue un vrai petit paiement test pour vérifier que tout fonctionne, puis vérifie que l'argent arrive bien sur ton compte NotchPay/Mobile Money

## Comment ça marche (pour comprendre ce que tu déploies)

- **`index.html`** : le site que voient tes visiteurs. Il n'a jamais accès à tes clés secrètes.
- **`netlify/functions/ask.js`** : reçoit la question, vérifie le quota gratuit ou le paiement, puis appelle l'IA avec ta clé Anthropic gardée côté serveur.
- **`netlify/functions/create-payment.js`** : démarre un paiement NotchPay et renvoie le lien de paiement Mobile Money.
- **`netlify/functions/verify-payment.js`** : quand l'utilisateur revient après avoir payé, vérifie auprès de NotchPay que le paiement est bien passé, puis délivre un "jeton" qui débloque l'accès illimité pendant 30 jours.

## Limites à connaître (honnêtement)

- Le quota gratuit (3 questions) est suivi dans le navigateur de l'utilisateur (localStorage). Une personne un peu technique pourrait le réinitialiser en vidant son cache. Pour une protection plus solide, il faudrait ajouter une vraie base de données (Netlify Blobs, Supabase, etc.) — je peux t'aider à faire cette évolution plus tard si le site grandit.
- Les tarifs NotchPay/Netlify peuvent évoluer : vérifie leurs pages de prix avant de fixer ton propre tarif.
- Pense à tester d'abord avec de petits montants avant de lancer à grande échelle.

## Prochaines étapes possibles

- Vérifier la signature des webhooks NotchPay pour plus de sécurité (voir leur documentation développeur)
- Ajouter un tableau de bord simple pour voir combien de personnes ont payé
- Contacter des ONG/coopératives agricoles pour leur proposer un abonnement groupé pour leurs membres
