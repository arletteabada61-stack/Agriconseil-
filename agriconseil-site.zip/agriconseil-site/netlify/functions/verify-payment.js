// netlify/functions/verify-payment.js
// Vérifie auprès de NotchPay qu'un paiement est bien complété, puis délivre
// un jeton signé (HMAC) que le navigateur garde pour prouver l'accès payé.
// Pas de base de données nécessaire : le jeton porte sa propre preuve, signée
// avec APP_SECRET, et expire après 30 jours.

const crypto = require("crypto");

const UNLOCK_DURATION_MS = 30 * 24 * 60 * 60 * 1000; // 30 jours

exports.handler = async (event) => {
  const reference = event.queryStringParameters && event.queryStringParameters.reference;

  if (!reference) {
    return { statusCode: 400, body: JSON.stringify({ error: "Référence manquante" }) };
  }

  try {
    const response = await fetch("https://api.notchpay.co/payments/" + reference, {
      method: "GET",
      headers: {
        Authorization: process.env.NOTCHPAY_PRIVATE_KEY,
      },
    });

    const data = await response.json();
    const status =
      (data.transaction && data.transaction.status) || data.status || "unknown";

    if (status !== "complete") {
      return {
        statusCode: 402,
        body: JSON.stringify({ error: "Paiement non confirmé", status }),
      };
    }

    const expiry = Date.now() + UNLOCK_DURATION_MS;
    const signature = crypto
      .createHmac("sha256", process.env.APP_SECRET)
      .update(reference + "." + expiry)
      .digest("hex");

    const token = reference + "." + expiry + "." + signature;

    return {
      statusCode: 200,
      body: JSON.stringify({ unlockToken: token }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erreur serveur", details: String(err) }),
    };
  }
};
