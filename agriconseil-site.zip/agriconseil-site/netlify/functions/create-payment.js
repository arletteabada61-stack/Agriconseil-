// netlify/functions/create-payment.js
// Initie un paiement NotchPay (MTN MoMo / Orange Money) et renvoie l'URL
// vers laquelle rediriger l'utilisateur pour payer.

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Requête invalide" }) };
  }

  const { email, phone } = body;
  if (!email) {
    return { statusCode: 400, body: JSON.stringify({ error: "Email requis (NotchPay l'exige)" }) };
  }

  const reference = "agri_" + Date.now() + "_" + Math.floor(Math.random() * 100000);
  const amount = process.env.PRICE_XAF || "500"; // prix en FCFA, modifiable via variable d'env
  const siteUrl = process.env.SITE_URL || "https://votre-site.netlify.app";

  try {
    const response = await fetch("https://api.notchpay.co/payments/initialize", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: process.env.NOTCHPAY_PUBLIC_KEY,
      },
      body: JSON.stringify({
        amount: amount,
        currency: "XAF",
        email: email,
        phone: phone || undefined,
        reference: reference,
        description: "AgriConseil — accès illimité",
        callback: siteUrl + "/?reference=" + reference,
      }),
    });

    const data = await response.json();

    if (!response.ok || !data.authorization_url) {
      return {
        statusCode: 502,
        body: JSON.stringify({ error: "Impossible d'initier le paiement", details: data }),
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        authorization_url: data.authorization_url,
        reference: reference,
      }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erreur serveur", details: String(err) }),
    };
  }
};
