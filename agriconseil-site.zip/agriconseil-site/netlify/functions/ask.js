// netlify/functions/ask.js
// Reçoit la question du site, vérifie l'accès (gratuit limité ou débloqué par paiement),
// puis appelle l'API Anthropic avec la clé secrète (jamais exposée au navigateur).

const crypto = require("crypto");

const FREE_QUESTIONS_PER_DEVICE = 3; // quota gratuit avant de demander un paiement

function isValidUnlockToken(token) {
  if (!token) return false;
  try {
    const [reference, expiry, signature] = token.split(".");
    if (!reference || !expiry || !signature) return false;
    if (Date.now() > parseInt(expiry, 10)) return false; // token expiré

    const expected = crypto
      .createHmac("sha256", process.env.APP_SECRET)
      .update(reference + "." + expiry)
      .digest("hex");

    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  } catch (e) {
    return false;
  }
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Requête invalide" }) };
  }

  const { question, category, budget, unlockToken, freeCount } = body;

  if (!question || question.trim().length === 0) {
    return { statusCode: 400, body: JSON.stringify({ error: "Question manquante" }) };
  }

  // --- Contrôle d'accès ---
  const unlocked = isValidUnlockToken(unlockToken);

  // Note : le compteur "freeCount" est envoyé par le navigateur (localStorage).
  // C'est une limite souple, pas une sécurité forte : un utilisateur technique
  // pourrait la contourner. Pour une vraie garantie, il faudrait une base de
  // données (ex: Netlify Blobs, FaunaDB, Supabase) qui compte par IP ou par
  // compte utilisateur. Suffisant pour démarrer et dissuader l'usage abusif.
  if (!unlocked && (freeCount || 0) >= FREE_QUESTIONS_PER_DEVICE) {
    return {
      statusCode: 402,
      body: JSON.stringify({
        error: "quota_exceeded",
        message: "Quota gratuit atteint. Débloque l'accès illimité pour continuer.",
      }),
    };
  }

  // --- Appel à l'API Anthropic (clé gardée côté serveur) ---
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system:
          "Tu es un conseiller agricole pragmatique qui s'adresse à de jeunes entrepreneurs agricoles francophones. Réponds de façon claire, concrète et actionnable, sans jargon inutile. Structure ta réponse en points courts si utile. Utilise **gras** pour les mots clés importants. Reste réaliste sur les coûts et les délais, et adapte précisément tes conseils au niveau de budget indiqué : " +
          (budget || "non précisé") +
          ". La catégorie de la question est : " +
          (category || "Général") +
          ". Limite ta réponse à environ 180 mots.",
        messages: [{ role: "user", content: question }],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        statusCode: 502,
        body: JSON.stringify({ error: "Erreur du service IA", details: data }),
      };
    }

    const answer = (data.content || [])
      .map((b) => b.text || "")
      .join("\n")
      .trim();

    return {
      statusCode: 200,
      body: JSON.stringify({ answer, unlocked }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erreur serveur", details: String(err) }),
    };
  }
};
